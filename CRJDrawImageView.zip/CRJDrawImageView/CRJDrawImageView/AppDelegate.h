//
//  AppDelegate.h
//  CRJDrawImageView
//
//  Created by 似云悠 on 2018/9/25.
//  Copyright © 2018年 似云悠. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

