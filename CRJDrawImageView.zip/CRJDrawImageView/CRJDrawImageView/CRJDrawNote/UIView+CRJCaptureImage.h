//
//  UIView+CRJCaptureImage.h
//  DrawNoteTest
//
//  Created by crj on 2018/8/6.
//  Copyright © 2018年 CRJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (CRJCaptureImage)

- (UIImage *)captureImage;

@end
